  <div id="app" class="app app-footer-fixed">
  <div id="footer" class="app-footer">
        {{$logo->footer_text}} (VERSION - 1.6.16)
  </div>
</div>