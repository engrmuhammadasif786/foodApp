<html>
    <body>
        <p>Order Cancelled: Your order id #{{$cart_id}} contains of {{$prod_name}} of price {{$currency_sign}} {{$price2}} has been cancelled.</p>
    </body>
</html>