<html>
    <body>
        <p>
        {{$store_n}} got an order cart id #{{$cart_id}} contains of {{$prod_name}} of price {{$currency_sign}} {{$price2}}. It will have to delivered on {{$delivery_date}} between {{$time_slot}}.
        
        </p>
    </body>
</html>