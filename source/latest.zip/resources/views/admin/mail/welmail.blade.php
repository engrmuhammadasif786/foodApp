<html>
    <body>
        <p>Welcome to Gogrocer family. We are Happy to have you here.</p><br>
        <h1>HAPPY SHOPPING !</h1>
    </body>
</html>