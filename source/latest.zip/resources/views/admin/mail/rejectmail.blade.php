<p> Hello {{$user->name}},</p>
<p><b> We are cancelling your order ({{$cart_id}}) due to following reason: </b></p><br>
<p> {{$cause}}</p>