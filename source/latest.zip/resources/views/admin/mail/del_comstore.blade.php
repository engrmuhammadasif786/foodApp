<html>
    <body>
        <p>Delivery Completed: Order id #{{$cart_id}} contains of {{$prod_name}} of price {{$currency_sign}} {{$price2}} is Delivered Successfully.</p>
    </body>
</html>